#' @title Sample genotype dataset
#'
#' @description A data.frame of genotype dataset for testing
#' @name rawGenoData
#' @docType data
#' @format data.frame
#' @usage rawGenoData
#'
#' @keywords datasets
NULL
